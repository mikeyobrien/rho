---
name: update-pi
description: Update the pi-coding-agent npm package to the latest version. Use when the user wants to update pi, upgrade pi, or get the latest version of the coding agent.
---

Run `npm update -g @mariozechner/pi-coding-agent` and report the version change.
